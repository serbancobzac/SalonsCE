function interetPopup() {
    $(".popup").toggle();
}